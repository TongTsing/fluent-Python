from .core import FrozenJSON

__all__ = ['FrozenJSON']